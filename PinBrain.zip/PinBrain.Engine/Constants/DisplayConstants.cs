﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PinBrain.Engine.Constants
{
    public static class DisplayConstants
    {
        public const string UNKNOWN = "UNKNOWN";
        //public const string STARTGAME = "STARTGAME";
        public const string BALLLOCK = "BALLLOCK";

        /// <summary>
        /// These are the modes in the game and their related commands and queries.
        /// </summary>
        public static class Modes
        {
            public static class AttractMode
            {
                public const string ATTRACT = "ATTRACT";
                public static class Commands
                {
                    /// <summary>
                    /// Sends 'StartPressed' command
                    /// </summary>
                    public const string STARTPRESSED = "StartPressed";
                }
            }
            public static class ActiveGameMode
            {
                public const string ACTIVEGAMEMODE = "ACTIVEGAMEMODE";

                public static class SubModes
                {
                    public static class CharacterSelectMode
                    {
                        public const string CHARSELECT = "CHARACTERSELECT";
                    }
                    public static class MultiballMode
                    {
                        public const string MULTIBALL = "MULTIBALL";
                    }
                }
            }
        }

        public static class CutScenes
        {
            public static class MapMode
            {
                public const string MAP = "MAP";
            }
            public static class Bonuses
            {
                public const string COLLECTBONUS = "CollectBonus";
                public const string SHOOTAGAIN = "ShootAgain";
            }
        }
    }
}
