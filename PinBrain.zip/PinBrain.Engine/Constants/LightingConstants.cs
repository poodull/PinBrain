﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PinBrain.Engine.Constants
{
    internal static class LightingConstants
    {
        public const string GILIGHTSTRING = "GILIGHTSTRING";
    }
}
