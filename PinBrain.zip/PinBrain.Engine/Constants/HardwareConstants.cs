﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PinBrain.Engine.Constants
{
    internal static class HardwareConstants
    {
        public const string LEDWIZ1 = "LedWiz1";
        public const string LEDWIZ2 = "LedWiz12";
    }
}
