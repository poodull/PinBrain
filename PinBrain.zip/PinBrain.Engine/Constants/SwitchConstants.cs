﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PinBrain.Engine.Constants
{
    public class SwitchConstants
    {
        //Enum of the switches for this game.  This is a 1-based array.
        public enum Switches
        {
            PlumbTilt = 1,
            Start = 2,
            Coin = 3,
            SlamTilt = 4,
            MenuSelect = 5,
            MenuBack = 6,
            MenuNext = 7,
            MenuExit = 8,
            Outhole = 9,
            RightBallTrough = 10,
            RightMidBallTrough = 11,
            MidBallTrough = 12,
            LeftMidBallTrough = 13,
            LeftBallTrough = 14,
            BallShooterLane = 15,
            RightFlipperEOS = 16,
            LeftFlipperEOS = 17,
            LeftDrain = 18,
            LeftReturn = 19,
            LeftSling = 20,
            RightSling = 21,
            RightReturn = 22,
            RightDrain =23,
            DraculaD = 24,
            DraculaR = 25,
            DraculaA = 26,
            DraculaC = 27,
            DraculaU = 28,
            DraculaL = 29,
            DraculaA2 = 30,
            BallPopper = 31,
            DropTargetA = 32,
            DropTargetB = 33,
            DropTargetC = 34,
            DropTargetD = 35,
            BelmontB = 36,
            BelmontE = 37,
            BelmontL = 38,
            BelmontM = 39,
            BelmontO = 40,
            BelmontN = 41,
            BelmontT = 42,
            LeftOuterOrbit = 43,
            RampExit = 44,
            LeftInnerOrbit = 45,
            BossTarget = 46,
            CenterExit = 47,
            CenterScoop = 48,
            RightInnerOrbit = 49,
            CapturedBall = 50,
            RightScoop = 51,
            RightOuterOrbit = 52,
            TopOuterOrbit = 53,
            LeftPop = 54,
            TopPop = 55,
            LowerPop = 56,
            LeftFlipper = 57,
            RightFlipper = 58
        }
    }
}
