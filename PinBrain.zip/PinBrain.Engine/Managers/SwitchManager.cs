﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
using System.Timers;

using log4net;

using PinBrain.Library.Switch;
using PinBrain.Devices.IO.IPAC;

using PinBrain.Engine.Constants;

namespace PinBrain.Engine.Managers
{
    public class SwitchManager
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(SwitchManager));

        private ISwitchDriver _driver;

        private Timer _pollSwitchTimer = new Timer(10);

        private static SwitchManager _instance;

        volatile private Switch[] _lastState = null;

        private SwitchManager()
        {
            _log.Info("Initializing SwitchManager...");
            //need to load the switch driver dynamically.
            //_driver = new IpacDriver(getSwitchesForGame());
            //_driver = new KeyCatcherForm(58);
            _driver = new ButtonForm(getSwitchesForGame());
            //_driver.OnSwitchEvent += new SwitchEventHandler(_driver_OnSwitchEvent);
            _pollSwitchTimer.Elapsed += new ElapsedEventHandler(switchpoll_timer_Elapsed);
            _pollSwitchTimer.Enabled = true;
        }

        /// <summary>
        /// Singleton pattern
        /// </summary>
        /// <returns></returns>
        protected static SwitchManager getInstance()
        {
            if (_instance == null)
                _instance = new SwitchManager();

            return _instance;
        }

        private PinBrain.Library.Switch.Switch[] getSwitchesForGame()
        {
            //load the game specific switches here.
            Switch[] switches = new Switch[58];
            switches[0] = new Switch(1, "PlumbBobTilt");
            switches[1] = new Switch(2, "StartButton");
            switches[2] = new Switch(3, "CoinChute");
            switches[3] = new Switch(4, "SlamTilt");
            switches[4] = new Switch(5, "MenuSelect");

            switches[5] = new Switch(6, "MenuBack");
            switches[6] = new Switch(7, "MenuNext");
            switches[7] = new Switch(8, "MenuExit");
            switches[8] = new Switch(9, "Outhole");
            switches[9] = new Switch(10, "RightTrough");

            switches[10] = new Switch(11, "RightMidTrough");
            switches[11] = new Switch(12, "MidTrough");
            switches[12] = new Switch(13, "LeftMidTrough");
            switches[13] = new Switch(14, "LeftTrough");
            switches[14] = new Switch(15, "BallShooterLane");

            switches[15] = new Switch(16, "RightFlipperEOS");
            switches[16] = new Switch(17, "LeftFlipperEOS");
            switches[17] = new Switch(18, "LeftOutlane");
            switches[18] = new Switch(19, "LeftInlane");
            switches[19] = new Switch(20, "LeftSling");

            switches[20] = new Switch(21, "RightSling");
            switches[21] = new Switch(22, "RightInlane");
            switches[22] = new Switch(23, "RightOutlane");
            switches[23] = new Switch(24, "DraculaD");
            switches[24] = new Switch(25, "DraculaR");

            switches[25] = new Switch(26, "DraculaA");
            switches[26] = new Switch(27, "DraculaC");
            switches[27] = new Switch(28, "DraculaU");
            switches[28] = new Switch(29, "DraculaL");
            switches[29] = new Switch(30, "DraculaA2");

            switches[30] = new Switch(31, "BallPopper");
            switches[31] = new Switch(32, "DropA");
            switches[32] = new Switch(33, "DropB");
            switches[33] = new Switch(34, "DropC");
            switches[34] = new Switch(35, "DropD");

            switches[35] = new Switch(36, "BelmontB");
            switches[36] = new Switch(37, "BelmontE");
            switches[37] = new Switch(38, "BelmontL");
            switches[38] = new Switch(39, "BelmontM");
            switches[39] = new Switch(40, "BelmontO");

            switches[40] = new Switch(41, "BelmontN");
            switches[41] = new Switch(42, "BelmontT");
            switches[42] = new Switch(43, "LeftOuterOrbit");
            switches[43] = new Switch(44, "RampExit");
            switches[44] = new Switch(45, "LeftInnerOrbit");

            switches[45] = new Switch(46, "BossTarget");
            switches[46] = new Switch(47, "CenterExit");
            switches[47] = new Switch(48, "CenterScoop");
            switches[48] = new Switch(49, "RightInnerOrbit");
            switches[49] = new Switch(50, "CapturedBallTarget");

            switches[50] = new Switch(51, "RightScoop");
            switches[51] = new Switch(52, "RightOuterOrbit");
            switches[52] = new Switch(53, "TopOuterOrbit");
            switches[53] = new Switch(54, "LeftPop");
            switches[54] = new Switch(55, "TopPop");

            switches[55] = new Switch(56, "LowerPop");
            switches[56] = new Switch(57, "LeftFlipper");
            switches[57] = new Switch(58, "RightFlipper");
            return switches;
        }

        [System.Runtime.CompilerServices.MethodImpl(
            System.Runtime.CompilerServices.MethodImplOptions.Synchronized)]
        void switchpoll_timer_Elapsed(object sender, ElapsedEventArgs e)
        {
            Switch[] state = _driver.SwitchArrayState;

            if (_lastState == null)
            {
                _lastState = new Switch[state.Length];
                state.CopyTo(_lastState, 0);
                GameManager.SwitchStateChanged(state);
                return;
            }
            //push to GM only switches that changed.
            List<Switch> changed = new List<Switch>();
            for (int i = 0; i < state.Length; i++)
            {
                if (state[i].State != _lastState[i].State)
                    changed.Add(state[i]);
            }
            state.CopyTo(_lastState, 0);
            if (changed.Count > 0)
            {
                StringBuilder sb = new StringBuilder();
                for (int i = 0; i < changed.Count; i++)
                {
                    sb.AppendFormat("{0}={1}", changed[i].Name, changed[i].State.ToString());
                }
                _log.Info("Sending changes to GameManager: " + sb);
                GameManager.SwitchStateChanged(changed.ToArray());
            }
        }

        internal static void Reset()
        {
            getInstance().reset();
        }

        private void reset()
        {
            //Make sure we can talk to the device.
        }

        /// <summary>
        /// Gets the last known state of the selected switch.
        /// </summary>
        /// <param name="switchIndex"></param>
        /// <returns></returns>
        public static Switch GetSwitch(SwitchConstants.Switches switchVal)
        {
            return _instance._lastState[(int)switchVal];
        }

        /// <summary>
        /// Writes to the switch device to fire the autoplunge mechanism.
        /// </summary>
        public static void Autoplunge()
        {
        }

        /// <summary>
        /// Writes to the switch device to fire the ball eject onto the shooter lane.
        /// </summary>
        public static void EjectBall()
        {
        }

        private void sendCommand(string command)
        {
            //_driver.SendCommand(command); //This belongs in a SolenoidDriver class.
        }

        internal static void EnableFlippers(bool isEnabled)
        {
            _instance.enableFlippers(isEnabled);
        }

        private void enableFlippers(bool isEnabled)
        {
            //sendCommand(string.Format(CMDENABLEFLIPPERS, isEnabled ? 1 : 0));
        }
    }
}
