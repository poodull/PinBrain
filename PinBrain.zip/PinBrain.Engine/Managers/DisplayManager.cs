﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;

using log4net;

using PinBrain.Devices.Display.Flash;
using PinBrain.Engine.Constants;
using PinBrain.Library.Feature;

namespace PinBrain.Engine.Managers
{
    public class DisplayManager
    {
        /// <summary>
        /// Republished event from any animation's completed event.
        /// </summary>
        public static event DisplayEventHandler OnAnimationCompleted;

        private static readonly ILog _log = LogManager.GetLogger(typeof(LightManager));
        private static DisplayManager _instance;
        private FlashHost _display;

        /// <summary>
        /// The current mode we're supposed to be displaying.
        /// </summary>
        private string _currentMode = DisplayConstants.UNKNOWN;

        /// <summary>
        /// Singleton pattern.
        /// </summary>
        private DisplayManager()
        {
            _log.Info("Initiating DisplayManager...");
            ////this is where we load the display controller.
            ////I should reflect the implementation I need,
            ////but for now we'll hardcode it.

            _display = new FlashHost();
            _display.OnAnimationCompleted += new DisplayEventHandler(_display_OnAnimationCompleted);
        }

        /// <summary>
        /// Singleton pattern
        /// </summary>
        /// <returns></returns>
        protected static DisplayManager getInstance()
        {
            if (_instance == null)
                _instance = new DisplayManager();

            return _instance;
        }

        private void _display_OnAnimationCompleted(DisplayEventArgs e)
        {
            if (OnAnimationCompleted != null)
                OnAnimationCompleted(e);
        }

        public static void PlaySequence(string sequenceName)
        {
            PlaySequence(sequenceName, -1);
        }

        public static void PlaySequence(string sequenceName, int scoreValue)
        {
            getInstance().playSequence(sequenceName, scoreValue);
        }

        internal static void Reset()
        {
            getInstance()._display.Reset();
        }

        internal static void ResetAnimation()
        {
            //if currentmode == attract
            getInstance()._display.SendCommandBackground("StartPressed");
        }

        internal static void CharacterPrevious()
        {
            getInstance()._display.SendCommandForeground("Previous");
        }

        internal static void CharacterNext()
        {
            getInstance()._display.SendCommandForeground("Next");
        }

        internal static string GetCharacterSelection()
        {
            return getInstance()._display.QueryForeground("GetSelected")
                .Replace("<string>", "").Replace("</string>", "");
        }

        private void playSequence(string sequenceName, int scoreValue)
        {
            if (string.IsNullOrEmpty(sequenceName) || sequenceName == _currentMode)
                return;
            _log.DebugFormat("Playing Display Sequence {0}", sequenceName);
            switch (sequenceName.ToUpperInvariant())
            {
                case DisplayConstants.Modes.AttractMode.ATTRACT:
                    _currentMode = DisplayConstants.Modes.AttractMode.ATTRACT;
                    _display.ShowAttract(DisplayConstants.Modes.AttractMode.ATTRACT);
                    break;
                case DisplayConstants.Modes.ActiveGameMode.SubModes.CharacterSelectMode.CHARSELECT:
                    _currentMode = DisplayConstants.Modes.ActiveGameMode.SubModes.CharacterSelectMode.CHARSELECT;
                    _display.ShowCharacterSelect(DisplayConstants.Modes.ActiveGameMode.SubModes.CharacterSelectMode.CHARSELECT);
                    break;
                case DisplayConstants.Modes.ActiveGameMode.ACTIVEGAMEMODE:
                    _currentMode = DisplayConstants.Modes.ActiveGameMode.ACTIVEGAMEMODE;
                    _display.ShowStartGame(DisplayConstants.Modes.ActiveGameMode.ACTIVEGAMEMODE);
                    break;
                case DisplayConstants.Modes.ActiveGameMode.SubModes.MultiballMode.MULTIBALL:
                    _display.ShowMultiball(DisplayConstants.Modes.ActiveGameMode.SubModes.MultiballMode.MULTIBALL);
                    break;
                default:
                    break;
            }
        }

        internal static void PlayCutScene(string scene)
        {
            if (string.IsNullOrEmpty(scene))
                return;
            _log.DebugFormat("Playing Cut Scene {0}", scene);
            switch (scene)
            {
                case DisplayConstants.CutScenes.Bonuses.COLLECTBONUS:
                    getInstance()._display.ShowCollectBonus(scene, PlayerStatus.CurrentPlayer);
                    break;
                case DisplayConstants.CutScenes.Bonuses.SHOOTAGAIN:
                    getInstance()._display.ShowShootAgain(scene, PlayerStatus.CurrentPlayer);
                    break;
                case DisplayConstants.CutScenes.MapMode.MAP:
                    getInstance()._display.ShowMap(scene, PlayerStatus.CurrentPlayer);
                    break;
                    //case DisplayConstants.CutScenes.
            }
        }

        internal static void SetGameStatus(IPlayerStatus playerStatus)
        {
            if (_instance._currentMode != DisplayConstants.Modes.ActiveGameMode.ACTIVEGAMEMODE)
                return;
            getInstance()._display.SetGameStatus(playerStatus);
        }
    }
}
