﻿using System;

using log4net;

using PinBrain.Engine.Constants;
using PinBrain.Library.Feature;
using PinBrain.Library.Switch;
using System.Threading.Tasks;
using System.Threading;

namespace PinBrain.Engine.Managers
{
    public enum InputMode
    {
        NoInput,
        NormalPlay,
        SelectPlayer,
        Merchant,
        Attract,
        Test
    }
    public partial class GameManager
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(GameManager));

        private static GameManager _instance;

        protected IMode _currentMode;

        protected InputMode _inputMode =  InputMode.Attract;

        protected bool _isTilted = false;

        /// <summary>
        /// Flag for if the save ball timer is on.
        /// </summary>
        protected bool _isSaveBallTimerOn = false;

        /// <summary>
        /// field keeps the number of balls expected on the field.
        /// </summary>
        protected int _ballsOnField = 0;

        /// <summary>
        /// the number of balls to be plunged.
        /// </summary>
        protected int _ballsToPlunge = 0;

        /// <summary>
        /// Flag to determine if all the balls that should be on the field are 
        /// to be auto-plunged.
        /// </summary>
        bool _isAutoPlungeOn = false;

        protected CancellationTokenSource _troughBallManagerCancelSource;

        /// <summary>
        /// The default ball saver timeout.  This should be a game setting.
        /// </summary>
        private const int BALLSAVERTIMEOUT = 5000;

        /// <summary>
        /// Timer to turn off the ball save timeout.
        /// </summary>
        private Timer _ballSaverTimer;

        private GameManager()
        {
            _log.Info("Initializing GameManager...");

            _troughBallManagerCancelSource = new CancellationTokenSource();
            Task.Factory.StartNew(() => troughBallManagerTask(), _troughBallManagerCancelSource.Token);
            _ballSaverTimer = new Timer(new TimerCallback((state) => { _isSaveBallTimerOn = false; }));
        }

        /// <summary>
        /// Singleton pattern
        /// </summary>
        /// <returns></returns>
        protected static GameManager getInstance()
        {
            if (_instance == null)
                _instance = new GameManager();

            return _instance;
        }

        /// <summary>
        /// Occurs when the tilt switches are tripped.
        /// </summary>
        /// <param name="warnings"></param>
        public void TiltWarning(int warnings) { }

        /// <summary>
        /// Occurs when the number of tilt warnings are exceeded.
        /// </summary>
        public void Tilted()
        {
            _isTilted = true;
        }

        /// <summary>
        /// The tilt recovery timer waits for all the balls to drain before
        /// continuing on.
        /// </summary>
        public void TiltRecovery() { }

        /// <summary>
        /// Adds a player to the player count.
        /// </summary>
        internal void AddPlayer()
        {
            if (PlayerStatus.CurrentPlayer == null || PlayerStatus.CurrentPlayer.NumPlayers < 4)
            {
                PlayerStatus.AddPlayer();
                //play sound
            }
        }
        /// <summary>
        /// Adds a credit
        /// </summary>
        internal void AddCredit()
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Initialize the table for a new game.
        /// </summary>
        public void ResetForNewGame()
        {
            PlayerStatus.Reset();
            AddPlayer();
            _ballsOnField = 0;
            _isTilted = false;
        }

        /// <summary>
        /// Reinitialize the Table for a new ball (either a new ball after
        /// the player has lost one or we have moved onto the next player.
        /// </summary>
        public void ResetForNewPlayer()
        {
            _ballsOnField = 0;
            _isTilted = false;
            _ballsToPlunge = 0;
            _isAutoPlungeOn = false; Task.Factory.StartNew(() =>
                 {
                     if (PlayerStatus.CurrentPlayer.PlayerCharacter == Characters.unknown)
                     {
                         _inputMode = InputMode.SelectPlayer;
                         DisplayManager.PlaySequence(DisplayConstants.Modes.ActiveGameMode.SubModes.CharacterSelectMode.CHARSELECT); //send high scores
                     }
                     else
                     {
                         //Need to task this out otherwise we get a AccessViolation and currupt memory.  unknown
                         StartPlay();
                     }
                 });
        }

        /// <summary>
        /// The timer used to delay the start of a game to allow attract
        /// sequence to complete.  When it expires it calls CreateNewBall().
        /// </summary>
        public void FirstBallTimerExpired() { } //not used

        /// <summary>
        /// The player has lost his ball (there are no more balls on the 
        /// playfield).
        /// </summary>
        public void EndOfBall()
        {
            _log.Debug("End of Ball for Player " + PlayerStatus.CurrentPlayer.PlayerUp);
            SwitchManager.EnableFlippers(false);
            _inputMode = InputMode.NoInput;
            CollectBonus();
        }

        /// <summary>
        /// Collect and reset the bonus points for this player.
        /// </summary>
        public void CollectBonus()
        {
            _log.Debug("Calculating Bonus for Player " + PlayerStatus.CurrentPlayer.PlayerUp);
            //calculate bonus
            DisplayManager.PlayCutScene(DisplayConstants.CutScenes.Bonuses.COLLECTBONUS);
            //now actually add the value to his score
            //PlayerStatus.CurrentPlayer.Score = ????
        }

        /// <summary>
        /// The Timer which delays the machine to allow any bonus points to 
        /// be added up has expired.  Check for Extra Balls and last ball.
        /// </summary>
        public void BonusCollected()
        {
            //animation's over, now check for extra ball or advance the player.
            if (PlayerStatus.CurrentPlayer.ExtraBalls > 0)
            {
                PlayerStatus.CurrentPlayer.ExtraBalls--;
            }
            else
            {
                //THIS SHOULD BE THE ONLY PLACE WE ADVANCE THE PLAYER
                PlayerStatus.CurrentPlayer.Ball++;
                PlayerStatus.CurrentPlayer.ResetPlayerStatus();
                PlayerStatus.NextPlayer(); //advance the player if there are no more extra balls
            }
            //Check if the last player's ball count is over the total limit.
            if (PlayerStatus.LastPlayer.Ball > 3)//TODO: Add Balls Per Play config setting
                EndOfGame();
            else
            {
                ResetForNewPlayer(); //right location for this?
            }
        }

        public void StartPlay()
        {
            //select user
            //ask the credit manager if we have credits
            PlayerStatus.CurrentPlayer.PlayerHealthStatus = "Player "
                + PlayerStatus.CurrentPlayer.PlayerUp + " is up";

            //Character is selected, now let's show the map.
            DisplayManager.PlayCutScene(DisplayConstants.CutScenes.MapMode.MAP);
            //DisplayManager.SetGameStatus(PlayerStatus.CurrentPlayer);
        }

        /// <summary>
        /// Occurs when the end of bonus display and it either ends the game
        /// or moves to next player.
        /// </summary>
        public void EndOfBallComplete() { }

        /// <summary>
        /// Called at the end of the game, after all players have lost all 
        /// balls.
        /// </summary>
        public void EndOfGame()
        {
            PlayerStatus.Reset();
            //Have to Task this out otherwise we get a memory access violation
            Task.Factory.StartNew(() =>
            {
                ModeStart(GameManagerConstants.ATTRACT);
            });
            _inputMode = InputMode.Attract;
        }

        /// <summary>
        /// Starts the Match sequence.
        /// </summary>
        public void Match() { }

        /// <summary>
        /// Award one or more credits.
        /// </summary>
        /// <param name="credits"></param>
        public void AwardFreeCredit(int credits) { }

        /// <summary>
        /// All players done, go back to Attract.
        /// </summary>
        public void EndPlay()
        {
            DisplayManager.PlaySequence(DisplayConstants.Modes.AttractMode.ATTRACT); //send high scores
        }

        /// <summary>
        /// Player lost a ball.  This is where we decrement the number of 
        /// balls on the playfield and test for end of game or end of ball.
        /// </summary>
        public void BallDrained()
        {
            if (!_isTilted)
            {
                //check if the ball timer has expired
                if (_isSaveBallTimerOn)
                {
                    _log.Debug("Ball Saver is active, Autoplunging ball.");
                    AutoPlungeBall();
                }
                else
                {
                    _ballsOnField--;
                    _log.Debug("Ball Drained.  Balls on field: " + _ballsOnField);
                    //check if that kills the current mode
                    if (_ballsOnField == 1)// && _currentMode is MultiBallMode)
                    {
                        //set mode to non-multiball 
                        //calculate multiball bonus
                    }
                }

                //check if that's the 
                if (_ballsOnField <= 0) //should we check _ballsToPlunge?
                {
                    EndOfBall();
                }
            }
        }

        private void AutoPlungeBall()
        {
            _isAutoPlungeOn = true;
        }

        protected void EjectBall()
        {
            //add to number of balls to eject.  
            //we create a counter and timer watchdog that monitors how many balls should be on the playfield.
            //if there's a ball in the trough already, we start auto-plunging.
            _isSaveBallTimerOn = true; //start timer
            _ballSaverTimer.Change(BALLSAVERTIMEOUT, Timeout.Infinite);
            _ballsToPlunge++;
        }

        private void troughBallManagerTask()
        {
            while (!_troughBallManagerCancelSource.IsCancellationRequested) //change to allow for Task Cancelling
            {
                while (_ballsOnField > 0)
                {
                    //if there any number of auto-plunged balls, start ejecting everything
                    //if there is a ball in the shooter lane, try to auto-plunge and wait until the lane clears (2s).
                    //SwitchManager.GetState(SwitchConstants.Switches.BallShooterLane).State = On;
                    //switchmanager.autoplunge();
                    System.Threading.Thread.Sleep(2000);
                }
                System.Threading.Thread.Sleep(2000);
            }
        }

        /// <summary>
        /// Add points to the score and update the scoreboard.
        /// </summary>
        /// <param name="points">The number of points scored.</param>
        public void AddScore(int points) { }

        /// <summary>
        /// The player has completed a jackpot score.
        /// </summary>
        /// <param name="points">The number of points for this jackpot.</param>
        public void AddJackpot(int points) { }

        /// <summary>
        /// Increment the playfield multiplier by this amount.
        /// </summary>
        /// <param name="amount"></param>
        public void IncrementBonusMultiplier(float amount) { }

        /// <summary>
        /// Set the Bonus Multiplier to the specified amount.
        /// </summary>
        /// <param name="level">The bonus level.</param>
        public void SetBonusMultiplier(float level) { }

        /// <summary>
        /// Award a special to the current player
        /// </summary>
        public void AwardSpecial() { }

        /// <summary>
        /// The player won an extra ball
        /// </summary>
        public void AwardExtraBall() { }

        internal static void Reset()
        {
            getInstance().reset();
        }

        private void reset()
        {

        }

        internal static void ModeStart(string mode)
        {
            switch (mode)
            {
                case GameManagerConstants.TEST:
                case GameManagerConstants.ATTRACT:
                    //getInstance().EndPlay();
                    if (getInstance()._currentMode != null)
                        getInstance()._currentMode.Dispose();
                    getInstance()._currentMode = new AttractMode();
                    break;
                //case GameManagerConstants.STARTGAME:
                //    if (getInstance()._currentMode != null)
                //        getInstance()._currentMode.Dispose();
                //    getInstance()._currentMode = new ActiveGameMode();
                //    break;
                case GameManagerConstants.NORMALPLAY:
                    if (getInstance()._currentMode != null)
                        getInstance()._currentMode.Dispose();
                    getInstance()._currentMode = new NormalPlayMode();
                    getInstance().ResetForNewGame();
                    break;
                default:
                    break;
            }
        }

        internal static void SwitchStateChanged(Switch[] state)
        {
            getInstance().switchStateChanged(state);
        }

        void switchStateChanged(Switch[] state)
        {
            if (_currentMode == null)
                return;
            _currentMode.SwitchStateChanged(state);
        }
    }
}
