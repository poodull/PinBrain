﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PinBrain.Library.Feature;
using PinBrain.Library.Switch;
using PinBrain.Engine.Constants;

namespace PinBrain.Engine.Managers
{
    public partial class GameManager
    {
        private class AttractMode : IMode
        {
            private bool _isDisposed = false;

            public AttractMode()
            {
                DisplayManager.PlaySequence(DisplayConstants.Modes.AttractMode.ATTRACT); //send high scores
            }

            #region * Dispose *
            //Call Dispose to free resources explicitly
            public void Dispose()
            {
                Dispose(true);
                //If dispose is called already then say GC to skip finalize on this instance.
                GC.SuppressFinalize(this);
            }

            ~AttractMode()
            {
                Dispose(false);
            }

            //Implement dispose to free resources
            protected virtual void Dispose(bool disposing)
            {
                if (!_isDisposed)
                {
                    _isDisposed = true;
                    // Released unmanaged Resources
                    if (disposing)
                    {
                        // Released managed Resources
                    }
                }
            }
            #endregion

            public void SwitchStateChanged(Switch[] _state)
            {
                for (int i = 0; i < _state.Length; i++)
                {
                    switch (_state[i].Id)
                    {
                        case (int)SwitchConstants.Switches.PlumbTilt:
                            break;
                        case (int)SwitchConstants.Switches.LeftFlipper:
                        case (int)SwitchConstants.Switches.RightFlipper:
                        case (int)SwitchConstants.Switches.Start:
                            if (_state[i].State == SwitchState.On)
                            {
                                if (_instance._inputMode == InputMode.Attract)
                                {
                                    //Start button Calls 'StartPressed' flash API
                                    DisplayManager.ResetAnimation();
                                    _instance.AddPlayer();
                                    ModeStart(GameManagerConstants.NORMALPLAY);
                                }
                            }
                            break;
                        case (int)SwitchConstants.Switches.Coin:
                            if (_state[i].State == SwitchState.On)
                            {
                                if (_instance._inputMode == InputMode.Attract)
                                {
                                    //add credit
                                    GameManager.getInstance().AddCredit();
                                    DisplayManager.ResetAnimation();
                                }
                            }
                            break;
                        case (int)SwitchConstants.Switches.SlamTilt:
                            break;
                        case (int)SwitchConstants.Switches.MenuSelect:
                            break;
                        case (int)SwitchConstants.Switches.MenuBack:
                            break;
                        case (int)SwitchConstants.Switches.MenuNext:
                            break;
                        case (int)SwitchConstants.Switches.MenuExit:
                            break;
                        case (int)SwitchConstants.Switches.Outhole:
                            break;
                        case (int)SwitchConstants.Switches.RightBallTrough:
                            break;
                        case (int)SwitchConstants.Switches.RightMidBallTrough:
                            break;
                        case (int)SwitchConstants.Switches.MidBallTrough:
                            break;
                        case (int)SwitchConstants.Switches.LeftMidBallTrough:
                            break;
                        case (int)SwitchConstants.Switches.LeftBallTrough:
                            break;
                        case (int)SwitchConstants.Switches.BallShooterLane:
                            break;
                        case (int)SwitchConstants.Switches.RightFlipperEOS:
                            break;
                        case (int)SwitchConstants.Switches.LeftFlipperEOS:
                            break;
                        case (int)SwitchConstants.Switches.LeftDrain:
                            break;
                        case (int)SwitchConstants.Switches.LeftReturn:
                            break;
                        case (int)SwitchConstants.Switches.LeftSling:
                            break;
                        case (int)SwitchConstants.Switches.RightSling:
                            break;
                        case (int)SwitchConstants.Switches.RightReturn:
                            break;
                        case (int)SwitchConstants.Switches.RightDrain:
                            break;
                        case (int)SwitchConstants.Switches.DraculaD:
                            break;
                        case (int)SwitchConstants.Switches.DraculaR:
                            break;
                        case (int)SwitchConstants.Switches.DraculaA:
                            break;
                        case (int)SwitchConstants.Switches.DraculaC:
                            break;
                        case (int)SwitchConstants.Switches.DraculaU:
                            break;
                        case (int)SwitchConstants.Switches.DraculaL:
                            break;
                        case (int)SwitchConstants.Switches.DraculaA2:
                            break;
                        case (int)SwitchConstants.Switches.BallPopper:
                            break;
                        case (int)SwitchConstants.Switches.DropTargetA:
                            break;
                        case (int)SwitchConstants.Switches.DropTargetB:
                            break;
                        case (int)SwitchConstants.Switches.DropTargetC:
                            break;
                        case (int)SwitchConstants.Switches.DropTargetD:
                            break;
                        case (int)SwitchConstants.Switches.BelmontB:
                            break;
                        case (int)SwitchConstants.Switches.BelmontE:
                            break;
                        case (int)SwitchConstants.Switches.BelmontL:
                            break;
                        case (int)SwitchConstants.Switches.BelmontM:
                            break;
                        case (int)SwitchConstants.Switches.BelmontO:
                            break;
                        case (int)SwitchConstants.Switches.BelmontN:
                            break;
                        case (int)SwitchConstants.Switches.BelmontT:
                            break;
                        case (int)SwitchConstants.Switches.LeftOuterOrbit:
                            break;
                        case (int)SwitchConstants.Switches.RampExit:
                            break;
                        case (int)SwitchConstants.Switches.LeftInnerOrbit:
                            break;
                        case (int)SwitchConstants.Switches.BossTarget:
                            break;
                        case (int)SwitchConstants.Switches.CenterExit:
                            break;
                        case (int)SwitchConstants.Switches.CenterScoop:
                            break;
                        case (int)SwitchConstants.Switches.RightInnerOrbit:
                            break;
                        case (int)SwitchConstants.Switches.CapturedBall:
                            break;
                        case (int)SwitchConstants.Switches.RightScoop:
                            break;
                        case (int)SwitchConstants.Switches.RightOuterOrbit:
                            break;
                        case (int)SwitchConstants.Switches.TopOuterOrbit:
                            break;
                        case (int)SwitchConstants.Switches.LeftPop:
                            break;
                        case (int)SwitchConstants.Switches.TopPop:
                            break;
                        case (int)SwitchConstants.Switches.LowerPop:
                            break;
                        default:
                            break;
                    }
                }
            }
        }
    }
}
