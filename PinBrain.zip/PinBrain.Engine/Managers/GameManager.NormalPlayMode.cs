﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PinBrain.Library.Switch;
using PinBrain.Library.Feature;
using PinBrain.Engine.Constants;

namespace PinBrain.Engine.Managers
{
    partial class GameManager
    {
        private class NormalPlayMode : IMode
        {
            private bool _isDisposed = false;

            public NormalPlayMode()
            {
                _instance.ResetForNewGame();
                _instance.ResetForNewPlayer();
                DisplayManager.OnAnimationCompleted += new DisplayEventHandler(DisplayManager_OnAnimationCompleted);
            }

            #region * Dispose *
            //Call Dispose to free resources explicitly
            public void Dispose()
            {
                Dispose(true);
                //If dispose is called already then say GC to skip finalize on this instance.
                GC.SuppressFinalize(this);
            }

            ~NormalPlayMode()
            {
                Dispose(false);
            }

            //Implement dispose to free resources
            protected virtual void Dispose(bool disposing)
            {
                if (!_isDisposed)
                {
                    _isDisposed = true;
                    // Released unmanaged Resources
                    if (disposing)
                    {
                        // Released managed Resources
                    }
                }
            }
            #endregion

            public void SwitchStateChanged(Switch[] _state)
            {
                //unlike other modes, NormalPlay will act on most switches.
                for (int i = 0; i < _state.Length; i++)
                {
                    switch (_state[i].Id)
                    {
                        case (int)SwitchConstants.Switches.PlumbTilt:
                            _instance.TiltWarning(PlayerStatus.CurrentPlayer.TiltWarnings++);
                            break;
                        case (int)SwitchConstants.Switches.Start:
                            if (_state[i].State == SwitchState.On)
                            {
                                if (_instance._inputMode == InputMode.SelectPlayer)
                                {
                                    if (PlayerStatus.CurrentPlayer.PlayerCharacter == Characters.unknown)
                                    {
                                        string player = DisplayManager.GetCharacterSelection();
                                        switch (player.ToLower())
                                        {
                                            case "maria":
                                                PlayerStatus.CurrentPlayer.PlayerCharacter = Characters.Maria;
                                                break;
                                            case "sypha":
                                                PlayerStatus.CurrentPlayer.PlayerCharacter = Characters.Sypha;
                                                break;
                                            case "grant":
                                                PlayerStatus.CurrentPlayer.PlayerCharacter = Characters.Grant;
                                                break;
                                            case "alucard":
                                                PlayerStatus.CurrentPlayer.PlayerCharacter = Characters.Alucard;
                                                break;
                                            case "richter":
                                            default:
                                                PlayerStatus.CurrentPlayer.PlayerCharacter = Characters.Richter;
                                                break;
                                        }
                                        _instance.StartPlay();
                                    }
                                }
                                else if (_instance._inputMode == InputMode.NormalPlay)
                                {
                                    //can only add a player if the current player is on ball 1
                                    if (PlayerStatus.CurrentPlayer.Ball == 1)
                                    {
                                        _instance.AddPlayer();
                                        DisplayManager.SetGameStatus(PlayerStatus.CurrentPlayer);
                                    }
                                }
                            }
                            break;
                        case (int)SwitchConstants.Switches.Coin:
                            if (_state[i].State == SwitchState.On)
                                _instance.AddCredit(); //
                            break;
                        case (int)SwitchConstants.Switches.SlamTilt:
                            break;
                        case (int)SwitchConstants.Switches.MenuSelect:
                            break;
                        case (int)SwitchConstants.Switches.MenuBack:
                            break;
                        case (int)SwitchConstants.Switches.MenuNext:
                            break;
                        case (int)SwitchConstants.Switches.MenuExit:
                            break;
                        case (int)SwitchConstants.Switches.Outhole:
                            if (_instance._inputMode == InputMode.NormalPlay)
                            {
                                 if (_state[i].State == SwitchState.On)
                                    _instance.BallDrained();
                            }
                            break;
                        case (int)SwitchConstants.Switches.RightBallTrough:
                            break;
                        case (int)SwitchConstants.Switches.RightMidBallTrough:
                            break;
                        case (int)SwitchConstants.Switches.MidBallTrough:
                            break;
                        case (int)SwitchConstants.Switches.LeftMidBallTrough:
                            break;
                        case (int)SwitchConstants.Switches.LeftBallTrough:
                            //if (_state[i].State == SwitchState.On)
                            //_instance.KickBack();
                            break;
                        case (int)SwitchConstants.Switches.BallShooterLane:
                            break;
                        case (int)SwitchConstants.Switches.RightFlipperEOS:
                            break;
                        case (int)SwitchConstants.Switches.LeftFlipperEOS:
                            break;
                        case (int)SwitchConstants.Switches.LeftDrain:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                            {
                                if (!_instance._isTilted)
                                {
                                    _instance.AddScore(1000);
                                    if (PlayerStatus.CurrentPlayer.HasShield)
                                    {
                                        //SolenoidManager.FireKickBack();
                                        PlayerStatus.CurrentPlayer.HasShield = false; //decrement
                                        DisplayManager.SetGameStatus(PlayerStatus.CurrentPlayer);
                                    }
                                }
                            }
                            break;
                        case (int)SwitchConstants.Switches.LeftReturn:
                            break;
                        case (int)SwitchConstants.Switches.LeftSling:
                            break;
                        case (int)SwitchConstants.Switches.RightSling:
                            break;
                        case (int)SwitchConstants.Switches.RightReturn:
                            break;
                        case (int)SwitchConstants.Switches.RightDrain:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                            {
                                if (!_instance._isTilted)
                                {
                                    _instance.AddScore(1000);
                                    PlayerStatus.CurrentPlayer.HasCross = false; //decrement
                                    DisplayManager.SetGameStatus(PlayerStatus.CurrentPlayer);
                                }
                            }
                            break;
                        case (int)SwitchConstants.Switches.DraculaD:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addDraculaLetter(0);
                            break;
                        case (int)SwitchConstants.Switches.DraculaR:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addDraculaLetter(1);
                            break;
                        case (int)SwitchConstants.Switches.DraculaA:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addDraculaLetter(2);
                            break;
                        case (int)SwitchConstants.Switches.DraculaC:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addDraculaLetter(3);
                            break;
                        case (int)SwitchConstants.Switches.DraculaU:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addDraculaLetter(4);
                            break;
                        case (int)SwitchConstants.Switches.DraculaL:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addDraculaLetter(5);
                            break;
                        case (int)SwitchConstants.Switches.DraculaA2:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addDraculaLetter(6);
                            break;
                        case (int)SwitchConstants.Switches.BallPopper:
                            break;
                        case (int)SwitchConstants.Switches.DropTargetA:
                            break;
                        case (int)SwitchConstants.Switches.DropTargetB:
                            break;
                        case (int)SwitchConstants.Switches.DropTargetC:
                            break;
                        case (int)SwitchConstants.Switches.DropTargetD:
                            break;
                        case (int)SwitchConstants.Switches.BelmontB:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addBelmontLetter(1);
                            break;
                        case (int)SwitchConstants.Switches.BelmontE:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addBelmontLetter(1);
                            break;
                        case (int)SwitchConstants.Switches.BelmontL:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addBelmontLetter(2);
                            break;
                        case (int)SwitchConstants.Switches.BelmontM:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addBelmontLetter(3);
                            break;
                        case (int)SwitchConstants.Switches.BelmontO:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addBelmontLetter(4);
                            break;
                        case (int)SwitchConstants.Switches.BelmontN:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addBelmontLetter(5);
                            break;
                        case (int)SwitchConstants.Switches.BelmontT:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addBelmontLetter(6);
                            break;
                        case (int)SwitchConstants.Switches.LeftOuterOrbit:
                            break;
                        case (int)SwitchConstants.Switches.RampExit:
                            break;
                        case (int)SwitchConstants.Switches.LeftInnerOrbit:
                            break;
                        case (int)SwitchConstants.Switches.BossTarget:
                            break;
                        case (int)SwitchConstants.Switches.CenterExit:
                            break;
                        case (int)SwitchConstants.Switches.CenterScoop:
                            break;
                        case (int)SwitchConstants.Switches.RightInnerOrbit:
                            break;
                        case (int)SwitchConstants.Switches.CapturedBall:
                            if (_state[i].State == SwitchState.On && _instance._inputMode == InputMode.NormalPlay)
                                _instance.addItem();
                            break;
                        case (int)SwitchConstants.Switches.RightScoop:
                            break;
                        case (int)SwitchConstants.Switches.RightOuterOrbit:
                            break;
                        case (int)SwitchConstants.Switches.TopOuterOrbit:
                            break;
                        case (int)SwitchConstants.Switches.LeftPop:
                            break;
                        case (int)SwitchConstants.Switches.TopPop:
                            break;
                        case (int)SwitchConstants.Switches.LowerPop:
                            break;
                        case (int)SwitchConstants.Switches.LeftFlipper:
                            if (_instance._inputMode == InputMode.SelectPlayer)
                                return;
                            if (_state[i].State == SwitchState.On)
                                DisplayManager.CharacterPrevious();
                            break;
                        case (int)SwitchConstants.Switches.RightFlipper:
                            if (_instance._inputMode == InputMode.SelectPlayer)
                                return;
                            if (_state[i].State == SwitchState.On)
                                DisplayManager.CharacterNext();
                            break;
                        default:
                            break;
                    }
                }
            }

            public void DisplayManager_OnAnimationCompleted(DisplayEventArgs e)
            {
                try
                {
                    //what animation completed?
                    if (e == null || e.SceneName == null)
                        return;
                    switch (e.SceneName)
                    {
                        case "MAP":
                            _instance._inputMode = InputMode.NormalPlay;
                            //we displayed the map, time to show the user status.
                            //TODO: Move this to BeginPlay
                            DisplayManager.PlaySequence(DisplayConstants.Modes.ActiveGameMode.ACTIVEGAMEMODE);
                            DisplayManager.SetGameStatus(PlayerStatus.CurrentPlayer);
                            GameManager._instance.EjectBall();
                            break;
                        case "CollectBonus":
                            //Call CollectBonusCompleted
                            GameManager._instance.BonusCollected();
                            break;
                        default:
                            break;
                    }
                }
                catch (Exception ex)
                {
                    _log.Error(ex);
                }
            }
        }
        internal void addItem()
        {
            throw new NotImplementedException();
        }

        internal void addBelmontLetter(int letterIndex)
        {
            if (!_isTilted)
            {
                PlayerStatus.CurrentPlayer.AddBelmontLetter(letterIndex);
                //DisplayManager.PlayCutScene(DisplayConstants.Modes.ActiveGameMode.AddBelmontLetter, letterIndex);
            }
        }

        internal void addDraculaLetter(int letterIndex)
        {
            if (!_isTilted)
            {
                PlayerStatus.CurrentPlayer.AddDraculaLetter(letterIndex);
            }
        }

    }
}
