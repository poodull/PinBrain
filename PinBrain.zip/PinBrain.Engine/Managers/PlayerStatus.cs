﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PinBrain.Library.Feature;
using PinBrain.Library;

namespace PinBrain.Engine.Managers
{
    public class PlayerStatus : IPlayerStatus
    {
        //private static PlayerStatus _instance;

        private static int _playerUp = 1; //the index of the current player. one based
        private static long[] _scores = new long[4];//the score for all players must be available for the scoreboard
        private static List<PlayerStatus> _players = new List<PlayerStatus>(4); //The array of players playing.  up to four.

        private int _ball = 1;
        private Characters _playerCharacter = Characters.unknown;
        private int _weapon = 0;
        private int _magic = 0;
        private int _shieldCount = 0;
        private int _crossCount = 0;
        private int _tiltWarnings = 0;
        private Levels _levelIndex;
        private int _roomIndex;
        private int _bonusMultiplier;
        private string _playerHealthStatus;

        private bool[] _belmont = new bool[7];
        private bool[] _dracula = new bool[7];

        /// <summary>
        /// Singleton.. or factory???
        /// </summary>
        private PlayerStatus()
        { }

        public static PlayerStatus CurrentPlayer
        {
            get
            {
                if (_players.Count == 0) return null;
                return _players[_playerUp - 1];
            }
        }

        /// <summary>
        /// The last player in the lineup.
        /// </summary>
        public static PlayerStatus LastPlayer
        {
            get
            {
                if (_players.Count == 0) return null;
                return _players[_players.Count - 1];
            }
        }

        public static void NextPlayer()
        {
            _playerUp++;
            if (_playerUp > _players.Count)
                _playerUp = 1;
        }

        public static void AddPlayer()
        {
            if (_players.Count < 4)
            {
                _players.Add(new PlayerStatus());
                System.Diagnostics.Debug.WriteLine("Adding Player.  Count is now: " + _players.Count);
            }
        }

        internal static void Reset()
        {
            _players.Clear();
        }

        /// <summary>
        /// The number of Tilt Warnings this player has exhausted so during this ball.
        /// </summary>
        public int TiltWarnings
        {
            get { return _tiltWarnings; }
            set { _tiltWarnings = value; }
        }

        /// <summary>
        /// The ball count the player is on.
        /// </summary>
        public int Ball
        {
            get { return _ball; }
            set { _ball = value; }
        }

        /// <summary>
        /// The number of extra balls the player has collected.
        /// This should only be >0 if the player is current player.
        /// There should be a cap of 2? extra balls per round.
        /// </summary>
        public int ExtraBalls { get; set; }

        public int PlayerUp
        {
            get { return PlayerStatus._playerUp; }
            set { PlayerStatus._playerUp = value; }
        }

        /// <summary>
        /// Get/Set which player index this is (1~4)
        /// </summary>
        public Characters PlayerCharacter
        {
            get { return _playerCharacter; }
            set
            {
                _playerCharacter = value;
                ResetPlayerStatus();
            }
        }
        /// <summary>
        /// Resets the player's status (weapons, shield, cross etc) to basic or 
        /// </summary>
        public void ResetPlayerStatus()
        {
            _tiltWarnings = 0;
            //_playerHealtStatus = HealthStates.Normal;
            for (int i = 0; i < _belmont.Length; i++)
            {
                _belmont[i] = false;
                _dracula[i] = false;
            }

            switch (_playerCharacter)
            {
                case Characters.Sypha:
                    _shieldCount = int.MaxValue;
                    _crossCount = int.MaxValue;
                    break;
                case Characters.Maria:
                    _shieldCount = int.MaxValue;
                    _crossCount = int.MaxValue;
                    break;
                case Characters.Grant:
                    _shieldCount = 2;
                    _crossCount = 2;
                    break;
                case Characters.Richter:
                    _shieldCount = 1;
                    _crossCount = 1;
                    break;
                case Characters.Alucard:
                    _shieldCount = 0;
                    _crossCount = 0;
                    break;
                default:
                    _shieldCount = 0;
                    _crossCount = 0;
                    _scores[0] = 0;
                    _scores[1] = 0;
                    _scores[2] = 0;
                    _scores[3] = 0;
                    _levelIndex = Levels.Ballroom; //DEBUG
                    _playerHealthStatus = string.Empty;
                    break;
            }
            _magic = 0;
            _weapon = 0;
            _roomIndex = 1;
        }

        public long[] Scores
        {
            get { return _scores; }
            set { _scores = value; }
        }

        public int NumPlayers
        {
            get { return _players.Count; }
        }

        public int Weapon
        {
            get { return _weapon; }
            set { _weapon = value; }
        }

        public int Magic
        {
            get { return _magic; }
            set { _magic = value; }
        }

        public bool HasShield
        {
            get { return _shieldCount > 0; }
            set { _shieldCount += value ? 1 : -1; } //ugly. should be another method for add/remove
        }

        public bool HasCross
        {
            get { return _crossCount > 0; }
            set { _crossCount += value ? 1 : -1; }
        }

        public Levels LevelIndex
        {
            get { return _levelIndex; }
            set { _levelIndex = value; }
        }

        public int RoomIndex
        {
            get { return _roomIndex; }
            set { _roomIndex = value; }
        }

        public int BonusMultiplier
        {
            get { return _bonusMultiplier; }
            set { _bonusMultiplier = value; }
        }

        public string PlayerHealthStatus
        {
            get { return _playerHealthStatus; }
            set { _playerHealthStatus = value; }
        }

        internal void AddBelmontLetter(int letterIndex)
        {
            _belmont[letterIndex] = true;
        }

        internal void AddDraculaLetter(int letterIndex)
        {
            _dracula[letterIndex] = true;
        }
    }
}
