﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using log4net;

using PinBrain.Engine;

[assembly: log4net.Config.XmlConfigurator(Watch = true)]
namespace PinBrain.Server
{
    class Program
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(Program));

        [STAThread()]
        static void Main(string[] args)
        {
            _log.Debug("Starting PinEngine.");
            Pingine engine = new Pingine();
            System.Windows.Forms.Application.Run();
            while (engine.IsRunning)
            {
                System.Threading.Thread.Sleep(1000);
            }
        }
    }
}
