﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PinBrain.Library.Feature
{
    public enum Characters
    {
        Sypha = 0,
        Maria = 1,
        Grant = 2,
        Richter = 3,
        Alucard = 4,
        unknown = 99
    }

    public interface IPlayerStatus
    {
        int Ball { get; }
        Characters PlayerCharacter { get; }
        long[] Scores { get; }
        int PlayerUp { get; }
        int NumPlayers { get; }
        int Weapon { get; }
        int Magic { get; }
        bool HasShield { get; }
        bool HasCross { get; }
        int TiltWarnings { get; }
        Levels LevelIndex { get; }
        int RoomIndex { get; }
        string PlayerHealthStatus { get; }
        int BonusMultiplier { get; }
    }
}
