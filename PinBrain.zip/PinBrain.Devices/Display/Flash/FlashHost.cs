﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;

using log4net;
using PinBrain.Library.Feature;

namespace PinBrain.Devices.Display.Flash
{
    /// <summary>
    /// </summary>
    /// <remarks>don't forget to add 
    /// ExternalInterface.addCallback("MyExposedFunction", null, 
    /// MyActionScriptFunction"); to the flash function</remarks>
    public partial class FlashHost : Form
    {
        public event DisplayEventHandler OnAnimationCompleted;

        private static readonly ILog _log = LogManager.GetLogger(typeof(FlashHost));

        private const string METHODSTRING = "<invoke name=\"{0}\" returntype=\"xml\"><arguments>{1}</arguments></invoke>";
        //private const string METHODSTRING = "<invoke name=\"{0}\" returntype=\"xml\"><arguments><string>{1}</string></arguments></invoke>";
        private const string METHODEMPTY = "<invoke name=\"{0}\" returntype=\"xml\"><arguments></arguments></invoke>";
        private const string METHODSETGAMESTATUS = "<invoke name=\"SetGameStatus\" returntype=\"xml\"><arguments><string>{0}</string><string>{1}</string><string>{2}</string><string>{3}</string><string>{4}</string><string>{5}</string><string>{6}</string></arguments></invoke>";

        string _playerstatusSwf = @"..\..\..\Dll\Flash\CMM.swf";
        string _multiballSwf = @"..\..\..\Dll\Flash\Multiball.Succubus.swf";
        string _attactSwf = @"..\..\..\Dll\Flash\AttractMode.swf";
        string _characterSelectSwf = @"..\..\..\Dll\Flash\CharacterSelect.swf";
        string _mapSwf = @"..\..\..\Dll\Flash\LevelMap.swf";
        string _collectBonus = @"..\..\..\Dll\Flash\CollectBonus.swf";

        IPlayerStatus _currentPlayerStatus;

        private object _lock = new object();

        public FlashHost()
        {
            InitializeComponent();

            flashBackground.FlashCall +=
                new AxShockwaveFlashObjects._IShockwaveFlashEvents_FlashCallEventHandler(
                    this.flashBackground_FlashCall);
            flashForeground.FlashCall +=
                new AxShockwaveFlashObjects._IShockwaveFlashEvents_FlashCallEventHandler(
                    flashForeground_FlashCall);

            resizeScreen();
            flashForeground.Visible = false;
            flashBackground.Visible = true;

            this.Show();
            _log.Info(Application.MessageLoop);
        }

        private void resizeScreen()
        {
            int w = Screen.PrimaryScreen.Bounds.Width;
            int h = (int)((double)w / 800.0 * 400.0);
            this.Width = w + 8;
            this.Height = h + 4;
            this.Left = -4;
            this.Top = -4;// Screen.PrimaryScreen.Bounds.Height - h;
        }

        private void flashBackground_FlashCall(object sender,
            AxShockwaveFlashObjects._IShockwaveFlashEvents_FlashCallEvent e)
        {
            string text = e.request;
            if (text.Contains("ANIMATIONCOMPLETED"))
            {
                if (OnAnimationCompleted != null)
                    OnAnimationCompleted(new DisplayEventArgs(flashBackground.Tag, "ANIMATIONCOMPLETED"));
            }
            if (text.StartsWith("<invoke name=\"API"))
                _log.Warn("Background API Definition: " + text);
            else
                _log.Debug("Flash Background Callback: " + e.request);
        }

        private void flashForeground_FlashCall(object sender,
            AxShockwaveFlashObjects._IShockwaveFlashEvents_FlashCallEvent e)
        {
            string text = e.request;
            if (text.Contains("FINISHEDMULTIBALL") ||
                text.Contains("FINISHEDBALLLOCK") ||
                text.Contains("FINISHEDJACKPOT") ||
                text.Contains("ANIMATIONCOMPLETED"))
            {
                lock (_lock)
                {
                    if (InvokeRequired)
                        return;
                    flashForeground.Visible = false;
                    flashForeground.Stop(); //foreground is used for cutscenes and may have sounds that don't stop.
                }
                if (OnAnimationCompleted != null)
                    OnAnimationCompleted(new DisplayEventArgs(flashForeground.Tag, "ANIMATIONCOMPLETED"));
            }
            if (text.StartsWith("<invoke name=\"API"))
                _log.Warn("Foreground API Definition: " + text);
            else
                _log.Debug("Flash Foreground Callback: " + text);
        }

        private string callFlashString(AxShockwaveFlashObjects.AxShockwaveFlash flash,
            string method, params object[] vals)
        {
            string response = string.Empty;

            StringBuilder sb = new StringBuilder();
            try
            {
                foreach (var param in vals)
                {
                    sb.AppendFormat("<string>{0}</string>", param);
                }

                _log.DebugFormat("Calling method: {0}[{1}]", method, sb.ToString());
                lock (_lock)
                {
                    response = flash.CallFunction(string.Format(METHODSTRING, method, sb.ToString()));
                }
                if (response != "<undefined/>") //void
                    _log.DebugFormat("Response from method: {0}[{1}] = {2}", method, sb.ToString(), response);
            }
            catch (Exception ex)
            {
                _log.ErrorFormat("Error Calling method {0} [{1}] on flash {2}. {3}",
                    method, sb.ToString(), flash.Name, ex.ToString());
            }
            return response;
        }

        private string callFlashEmpty(AxShockwaveFlashObjects.AxShockwaveFlash flash,
            string method)
        {
            string response = string.Empty;

            try
            {
                _log.DebugFormat("Calling method: {0}", method);
                lock (_lock)
                {
                    response = flash.CallFunction(string.Format(METHODEMPTY, method));
                }
                if (response != "<undefined/>") //void
                    _log.DebugFormat("Response from method: {0} = {1}", method, response);
            }
            catch (Exception ex)
            {
                _log.ErrorFormat("Error Calling method {0} on flash {1}. {2}",
                    method, flash.Name, ex.ToString());
            }
            return response;
        }

        //public void CallFunction(string methodName, string varName, int val)
        //{
        //    flash1.CallFunction(string.Format(METHODSTRING, methodName,
        //        varName, val));
        //}

        /// <summary>
        /// Shown on the FOREGROUND
        /// </summary>
        /// <param name="status"></param>
        public void SetGameStatus(IPlayerStatus status)
        {
            if (status == null) return; //nothing to display

            _currentPlayerStatus = status; //keep a pointer to what should be displayed if we're not showing it now.
            if (!flashBackground.Movie.Equals(new FileInfo(_playerstatusSwf).FullName))
            {
                _log.Error("Cannot SetGameStatus because current movie on background is " + flashBackground.Movie);
                return;
            }
            try
            {
                //we may not be showing the GameScreen.
                //_log.Debug("NOW SHOWING ONE BACKGROUND: " + flashBackground.Movie);
                lock (_lock)
                {
                    string response = flashBackground.CallFunction(string.Format(METHODSETGAMESTATUS,
                        _currentPlayerStatus.Ball,
                        _currentPlayerStatus.Scores[0],
                        _currentPlayerStatus.Scores[1],
                        _currentPlayerStatus.Scores[2],
                        _currentPlayerStatus.Scores[3],
                        _currentPlayerStatus.PlayerUp,
                        _currentPlayerStatus.NumPlayers));
                    //TODO: This method needs to have all of these functions as well.
                    callFlashString(flashBackground, "SetCharacterIndex", (int)_currentPlayerStatus.PlayerCharacter);
                    callFlashString(flashBackground, "SetShield", _currentPlayerStatus.HasShield ? "1" : "0");
                    callFlashString(flashBackground, "SetCross", _currentPlayerStatus.HasCross ? "1" : "0");
                    callFlashString(flashBackground, "SetMagicLevel", _currentPlayerStatus.Magic);
                    callFlashString(flashBackground, "SetWeaponLevel", _currentPlayerStatus.Weapon);
                    callFlashString(flashBackground, "SetPlayerStatus", _currentPlayerStatus.PlayerHealthStatus);
                    callFlashString(flashBackground, "SetBonusValue", _currentPlayerStatus.BonusMultiplier);
                }
            }
            catch (Exception ex)
            {
                _log.Error("Error setting GameStatus.", ex);
            }
        }
        /// <summary>
        /// Shown on the FOREGROUND
        /// </summary>
        /// <param name="key"></param>
        public void ShowMultiball(string key)
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(delegate
                {
                    ShowMultiball(key);
                }));
            }
            else
            {
                if (flashForeground.Visible)
                    return;
                lock (_lock)
                {
                    flashForeground.LoadMovie(0, " ");
                    flashForeground.Visible = true;
                    FileInfo fi = new FileInfo(_multiballSwf);
                    if (!fi.Exists)
                        throw new FileNotFoundException("swf not found.", fi.FullName);
                    flashForeground.LoadMovie(0, fi.FullName);
                    callFlashEmpty(flashForeground, "ShowMultiball");
                }
                flashForeground.Tag = key;
            }
        }
        /// <summary>
        /// Shown on the FOREGROUND
        /// </summary>
        /// <param name="key"></param>
        /// <param name="ball"></param>
        public void ShowBallLock(string key, int ball)
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(delegate
                {
                    ShowBallLock(key, ball);
                }));
            }
            else
            {
                lock (_lock)
                {

                    if (flashForeground.Visible)
                        return;
                    flashForeground.LoadMovie(0, " ");
                    flashForeground.Visible = true;
                    FileInfo fi = new FileInfo(_multiballSwf);
                    if (!fi.Exists)
                        throw new FileNotFoundException("swf not found.", fi.FullName);
                    flashForeground.LoadMovie(0, fi.FullName);
                    callFlashString(flashForeground, "ShowBallLock", ball);
                    flashForeground.Tag = key;
                }
            }
        }
        /// <summary>
        /// Shown on the BACKGROUND
        /// </summary>
        /// <param name="key"></param>
        public void ShowAttract(string key)
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(delegate
                {
                    ShowAttract(key);
                }));
            }
            else
            {
                flashForeground.Visible = false;
                flashBackground.Visible = true;
                flashForeground.LoadMovie(0, " ");
                FileInfo fi = new FileInfo(_attactSwf);
                if (!fi.Exists)
                    throw new FileNotFoundException("swf not found.", fi.FullName);
                flashBackground.LoadMovie(0, fi.FullName);
                //callFlashEmpty(flashBackground, "ShowAtractMode");
                //Need to seed the high scores.
            }
        }

        /// <summary>
        /// Shown on the BACKGROUND
        /// </summary>
        /// <param name="key"></param>
        public void ShowStartGame(string key)
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(delegate
                {
                    ShowStartGame(key);
                }));
            }
            else
            {
                lock (_lock)
                {

                    flashForeground.Visible = false;
                    flashBackground.Visible = true;
                    _log.DebugFormat("Loading swf file: {0} into Background.", _playerstatusSwf);
                    FileInfo fi = new FileInfo(_playerstatusSwf);
                    if (!fi.Exists)
                        throw new FileNotFoundException("swf not found.", fi.FullName);
                    flashBackground.Movie = (fi.FullName);
                    flashBackground.Tag = key;
                }
            }
        }

        /// <summary>
        /// Shown on the FOREGROUND
        /// </summary>
        /// <param name="key"></param>
        public void ShowCharacterSelect(string key)
        {
            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(delegate
                {
                    ShowCharacterSelect(key);
                }));
            }
            else
            {
                flashForeground.Visible = true;
                //flashBackground.Visible = false;
                _log.DebugFormat("Loading swf file: {0} into Foreground.", _characterSelectSwf);
                FileInfo fi = new FileInfo(_characterSelectSwf);
                if (!fi.Exists)
                    throw new FileNotFoundException("swf not found.", fi.FullName);
                flashForeground.Movie = (fi.FullName);
                flashForeground.Tag = key;
            }
        }

        public void Reset()
        {
            //TODO: Reset the display. to what exactly?
        }

        public void SendCommandForeground(string command)
        {
            callFlashEmpty(flashForeground, command);
        }

        public void SendCommandBackground(string command)
        {
            callFlashEmpty(flashBackground, command);
        }

        public string QueryForeground(string command)
        {
            return callFlashEmpty(flashForeground, command);
        }

        public string QueryBackground(string command)
        {
            return callFlashEmpty(flashBackground, command);
        }

        public void ShowMap(string key, IPlayerStatus status)
        {
            if (status == null) return; //nothing to display

            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(delegate
                {
                    ShowMap(key, status);
                }));
            }
            else
            {
                lock (_lock)
                {
                    _currentPlayerStatus = status; //keep a pointer to what should be displayed if we're not showing it now.
                    flashForeground.Visible = true;
                    //flashBackground.Visible = false;
                    _log.DebugFormat("Loading swf file: {0} into Foreground.", _mapSwf);
                    FileInfo fi = new FileInfo(_mapSwf);
                    if (!fi.Exists)
                        throw new FileNotFoundException("swf not found.", fi.FullName);
                    flashForeground.Movie = (fi.FullName);
                    flashForeground.Tag = key; //not used

                    callFlashString(flashForeground, "ShowLevelMap", (int)_currentPlayerStatus.LevelIndex, _currentPlayerStatus.RoomIndex);
                }
            }
        }

        public void ShowCollectBonus(string key, IPlayerStatus status)
        {
            if (status == null) return; //nothing to display

            if (InvokeRequired)
            {
                Invoke(new MethodInvoker(delegate
                {
                    ShowCollectBonus(key, status);
                }));
            }
            else
            {
                _currentPlayerStatus = status; //keep a pointer to what should be displayed if we're not showing it now.
                flashForeground.Visible = true;
                //flashBackground.Visible = false;
                _log.DebugFormat("Loading swf file: {0}  into Background.", _collectBonus);
                FileInfo fi = new FileInfo(_collectBonus);
                if (!fi.Exists)
                    throw new FileNotFoundException("swf not found.", fi.FullName);
                flashForeground.Movie = (fi.FullName);
                flashForeground.Tag = key; //not used

                string stageBonus = "1000000";
                string bonusLevel = "2";
                string hearts = "85";
                string heartValue = "1000";
                string enemiesKilled = "200";
                string enemyValue = "500";
                callFlashString(flashForeground, "CollectBonus", "endofball", status.Scores[status.PlayerUp], stageBonus, bonusLevel, hearts, heartValue, enemiesKilled, enemyValue);
                //CollectBonus(reason:String[stagecleared,endofball], baseScore:String, stageBonus:String, bonusLvl:String, hearts:String, heartValue:String, enemies:String, enemyValue:String):void");
            }
        }

        public void ShowShootAgain(string scene, IPlayerStatus status)
        {
        }
    }
}
