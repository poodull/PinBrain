﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using PinBrain.Library.Switch;

namespace PinBrain.Devices.IO.Serial
{
    public class SolenoidArduino : Arduino
    {
        private Switch[] _state;

        //public event SwitchEventHandler OnSwitchEvent;
        public SolenoidArduino(string port)
            : base(port)
        {
            _log.InfoFormat("SolenoidArduino defined on port {0}", port);
        }

        public Switch[] SwitchArrayState
        {
            get { return _state; }
        }

        /// <summary>
        /// Sends a switch state array to the arduino.  I don't think we can use this.
        /// can't afford to send tons of data to the arduino, which might pause and keep a 
        /// solenoid fired.  Use SendCommand(ArduinoCommands.ForceSwitchState);
        /// </summary>
        /// <param name="array"></param>
        public void ForceSwitchState(byte[] array)
        {
            //string stringarray = string.Empty;
            //for (int i = 0; i < array.Length; i++)
            //{
            //    stringarray += array[i];
            //}
            _serial.Write(array, 0, array.Length);
        }
    }
}
