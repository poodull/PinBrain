﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using PinBrain.Library.Switch;
using log4net;

namespace PinBrain.Devices.IO.IPAC
{
    public partial class ButtonForm : Form, ISwitchDriver
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(ButtonForm));
        Switch[] _state;

        public ButtonForm(Switch[] state)
        {
            InitializeComponent();
            _state = state;
            loadSwitches(_state);
            listView1.ItemChecked += new ItemCheckedEventHandler(listView1_ItemChecked);
            listView1.ItemCheck += new ItemCheckEventHandler(listView1_ItemCheck);
            this.Show();
        }

        void listView1_ItemCheck(object sender, ItemCheckEventArgs e)
        {
            try
            {
                _state[e.Index].State = e.NewValue == CheckState.Checked ? SwitchState.On : SwitchState.Off;
            }
            catch (Exception ex)
            {
                _log.Error(ex);
            }

            //if (_state[e.Index].State != _state[e.Index].LastState && OnSwitchEvent != null)
            //    OnSwitchEvent(this, e.Index);
        }

        void listView1_ItemChecked(object sender, ItemCheckedEventArgs e)
        {

        }

        private void loadSwitches(Switch[] _state)
        {
            foreach (var sw in _state)
            {
                ListViewItem itm = listView1.Items.Add(sw.Id.ToString());
                itm.SubItems.Add(sw.Name);
                itm.SubItems.Add(sw.State.ToString());
            }
        }

        public event SwitchEventHandler OnSwitchEvent;

        public Switch[] SwitchArrayState
        {
            get { return _state; }
        }
    }
}
