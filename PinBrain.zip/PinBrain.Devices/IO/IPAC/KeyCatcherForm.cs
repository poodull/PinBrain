﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

using log4net;

using PinBrain.Library.Switch;

namespace PinBrain.Devices.IO.IPAC
{
    public partial class KeyCatcherForm : Form, ISwitchDriver
    {
        private static readonly ILog _log = LogManager.GetLogger(typeof(KeyCatcherForm));
        Switch[] _state;

        public KeyCatcherForm(int size)
        {
            InitializeComponent();
            _state = new Switch[size];
        }

        private void KeyCatcherForm_KeyDown(object sender, KeyEventArgs e)
        {
            _log.DebugFormat("key {0} Down.", e.KeyValue);
        }

        private void KeyCatcherForm_KeyUp(object sender, KeyEventArgs e)
        {
            _log.DebugFormat("key {0} Up.",e.KeyValue);
        }

        private void KeyCatcherForm_KeyPress(object sender, KeyPressEventArgs e)
        {

        }

        #region ISwitchDriver Members

        public event SwitchEventHandler OnSwitchEvent;

        public Switch[] SwitchArrayState
        {
            get { return _state; }
        }

        #endregion
    }
}
